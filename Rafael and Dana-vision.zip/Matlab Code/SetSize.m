function [ img ] = SetSize( img )
% SetSize
%
% Basic description: This function is used for pre-processing before
% attempting to detect a wave in an image. It resizes the image so that
% the radii of circles in the image will be large enough to
% find with fairly good accuracy.
%
% Input: 
% Image of a jewel.
%                   
% Output: 
% Resized image.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

[ Rmin Rmax ] = GetRadiiRange(img);
temp_img = img;
i = 2;
while (Rmin < 15)
    temp_img = imresize(img,i);
    [ Rmin Rmax ] = GetRadiiRange(temp_img);
    i = i + 1;
end
img = temp_img;

end

