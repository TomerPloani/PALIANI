function Vector = assignNumericVals(fullEPVector,Xlength)
% assignNumericVals
%
% Basic description: the function recieves a vector of Y values of all nine
% extreme points and the length of X axis. It outputs a vector of nine
% new values computed by Y values in relation to length of X axis.
%
% Input: 
% fullEPVector - vector of Y values of all nine extrme points.
% Y value is defined by length in pixels from X axis.
% Xlength - length of X axis in pixels                     
%
% Output: 
% Vector - a vector of nine values where each value is computed by Yvalue
% of extreme point devided by length of X axis. This vector is the final
% numeric value that a pendant recieves and is the one that will be matched
% with other vectors in the database.
%
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses

% Reset Vector to 0
Vector = [0,0,0,0,0,0,0,0,0];
for i = 1:9
    % The value is multiplied by 28 for convinenece of comparison
    Vector(i) = (fullEPVector(i,2)/Xlength)*(28);
end