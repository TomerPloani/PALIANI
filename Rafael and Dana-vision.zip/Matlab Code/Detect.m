function [ bbox ] = Detect( detector, img )
%Detect
% Basic description: Detects a jewel in the given image using
% the given detector. The function assumes the wanted jewel will
% be in the largest matching area.
% To mark the matched area on the image, which is useful for debugging,
% use (after line 23):
% detectedImg = insertShape(img, 'rectangle', bbox, 'Color', [255 0 0]);
% imshow(detectedImg);
%
% Input: 
% Image and detector.
%                   
% Output: 
% The jewel appearing in the image.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

bbox = step(detector, img);

%heuristic: get largest detected object
bbox = GetLargestRec(bbox);

end

