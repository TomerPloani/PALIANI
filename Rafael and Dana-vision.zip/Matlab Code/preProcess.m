function [processedImage,firstX,lastX,BW] = preProcess(I)
% preProcess
%
% Basic description: this method recieves an image after cropping process.
% The image is of the middle part of the pendant where the wave appears.
% The method returns a binary image of the exterior of the wave and clears
% out any noises that may appear (inconsistent noises caused by light 
% reflections of the material of the pendant).
% 
%
% Input: 
% I - rgb image of pendant after cropping.      
%                   
% Output: 
% processedImage - binary image of the exterior of the wave without any
% noises
% firstX - begining of wave
% lastX - end of wave
% BW- a black/white image of wave isolated from pendant before noise removal 
% (for demonstration purposes in GUI)
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses


% get number of pixels in I 
[m,n,~]= size(I);
dimensions = m*n;

% make a black/white image
BW = rgb2gray(I);


% return to RGB format but BW values
rgb=BW(:,:,[1 1 1]);

% converting the image to HSV space
HSV = rgb2hsv(rgb); 

% get the histogram of the V value of the HSV image
array = imhist(HSV(:,:,3));


% get the exact point in the V histogram  seperating between the dark
% pixels of the wave and the brighter pixels of the pendant
risePoint = getRise(array,dimensions);

% Create a binary image that colors the dark pixels black and the bright
% pixels white
[BW,~] = createMask(rgb,risePoint);


% switch between black and white pixels 
BW2 = (BW - 1)*(-1);

% get boundaries of the binary image - "bwboundaries" tags every object
% seperatley and for each object returns the indexes of its exterior
B = bwboundaries(BW2);

% isolaterWave returns the largest of the exteriors returned by bwboundaries.
% it is expected that the object with the largest exterior will be the
% wave.
vectorWave = isolateWave(B);

% createProcessedImage returns a binary image of the exterior of the wave.
% the exterior of the wave is white and BG is black
[processedImage,firstX,lastX] = createProcessedImage(I,vectorWave);
end

