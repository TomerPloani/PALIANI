function [ angle ] = GetRotationAngle( centers )

%GetRotationAngle
% Basic description: This function calculates the angle in which
% an image must be rotated to become straight. To achieve this the
% function assumes that at least two points in the given vector
% lie on a straight line in the final image.
%
% Input: 
% A vector containing at least two points. Assumed to be centers of
% of two opposing circles.
%                   
% Output: 
% Angle in which to rotate the image.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

c1_x = centers(2,1);
c1_y = centers(2,2);
c2_x = centers(1,1);
c2_y = centers(1,2);

p = polyfit([c1_x c2_x], [c1_y c2_y], 1);
slope = p(1);
angle = radtodeg(atan(slope));


end

