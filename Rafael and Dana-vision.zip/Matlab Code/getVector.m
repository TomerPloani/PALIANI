function Vector = getVector(I)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% Preprocess homographed image to get a black/white image of the exterior of
% the wave without any noises
[processedImage,firstX,lastX] = preProcess(I);

% turn the wave into a discrete function representing the middle
% line of the wave
arrayIndex = turnToFunction(processedImage,firstX,lastX);

% normalize the function so that the X axis of the function will be the X
% axis of the wave itself
arrayIndexN = normalizeArray(arrayIndex);

% find the Max extreme points of the function
[locsMax, pksMax,X,Y] = findMaxPoints(arrayIndexN);

% find the Max extreme points of the function
[locsMin, pksMin ] = findMinPoints(arrayIndexN);

% Compute length of X axis 
Xlength = lastX - firstX + 1;

% combine X and Y values of Max points
fullMax = [locsMax,pksMax];

% combine X and Y values of Min points
fullMin = [locsMin,pksMin];

% checks wether all exreme points are in expeced location based on preknown
% fetures of the pendant
fullEPVector = checkExtremePoints(fullMin,fullMax,Xlength);

%for display
%figure
%XforPlot = fullEPVector(:,1);
%YforPlot = fullEPVector(:,2);
%plot(X,Y,XforPlot,YforPlot,'O')
%pause;

% check if there are any zeros in fullEPVector, if there are return "make
% another picture"
n = nnz(fullEPVector);
%if (n ~= 9)
    % Return to GUI "make another picture"

%disp(fullEPVector);
%pause;

% assign numeric values to the wave for future comparison with other waves
% in the database
Vector = assignNumericVals(fullEPVector,Xlength);
%disp(Vector);
%pause;
