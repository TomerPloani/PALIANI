function [ Rmin Rmax ] = GetRadiiRange( img )
%GETRADIIRANGE 
%
% Basic description: Returns the expected radii range of a jewel's
% holed circle, assuming the ratio between the image area and a circle
% area is within expected range.
%
% Input: 
% Image of a jewel.
%                   
% Output: 
% Expected radii of holes to be found.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses
minRatio = 0.005;
maxRatio = 0.008;

sizePic = size(img);
areaPic = sizePic(1) * sizePic(2);
Rmin = int8(sqrt(minRatio * areaPic) / 2);
Rmax = int8(sqrt(maxRatio * areaPic) / 2);

end

