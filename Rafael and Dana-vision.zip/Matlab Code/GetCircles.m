function [ centers, radii ] = GetCircles( img )

%GETCIRCLES
% Basic description: This function will attempt to located circles in
% in a given image according to pre-defined specifications, which were
% determined considering the properties of a wave-jewel.
% This function is meant to be run on the output of SetSize(img).
%
% Input: 
% Image of a jewel after pre-processing via SetSize.
%                   
% Output: 
% Circles found in the image, matching expected radii and located
% in designated areas in the image.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

[Rmin, Rmax] = GetRadiiRange(img);

% In some situations it is beneficial to use two-stage discovery of circles.
% add 'Method','twostage' to the function parameters.
[centers, radii] = imfindcircles(img, [Rmin Rmax], 'ObjectPolarity','dark', 'Sensitivity', 0.96);

% Return the circles in pre-designated areas only.
[centers, radii] = FilterCircles(img, centers, radii);

end

