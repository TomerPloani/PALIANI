function toReturn = checkExtremePoints(MinPoints,MaxPoints,Xlength)
% checkExtremePoints
%
% Basic description: this function recieves suspect extreme points, rules
% out extreme points that are not in expected locations and keeps those in
% expected locations. Expected locations of extreme points are constant 
% for all pendants and were given as parameters by the manufacturer.
%
% Input: 
% MInPoints - array of (x,y) values of all suspect minimal extreme points 
% MaxPoints - array of (x,y) values of all suspect maximal extreme points 
% Both arrays are sorted by X value in increasing order
% Xlength - length of X axis in pixels        
%                   
%
% Output: 
% toReturn - A vector of (x,y) values of nine extreme points as such: 
% [Min,Max,Min,Max,Min,Max,Min,Max,Min]
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses

% defining range of where first Min point should be. 
left1 = Xlength*0.1194;
right1 = Xlength*0.164;

% defining range of where first Max point should be. 
left2 = Xlength*0.2126;
right2 = Xlength*0.2574;

% defining range of where second Min point should be. 
left3 = Xlength*0.3059;
right3 = Xlength*0.3507;

% defining range of where second Max point should be. 
left4 = Xlength*0.4029;
right4 = Xlength*0.44776;

% defining range of where third Min point should be. 
left5 = Xlength*0.48507;
right5 = Xlength*0.5298;

% defining range of where third Max point should be. 
left6 = Xlength*0.5708;
right6 = Xlength*0.6231;

% defining range of where fourth Min point should be. 
left7 = Xlength*0.6716;
right7 = Xlength*0.7164;

% defining range of where fourth Max point should be. 
left8 = Xlength*0.753;
right8 = Xlength*0.7985;

% defining range of where fifth Min point should be. 
left9 = Xlength*0.8619;
right9 = Xlength*0.9067;

%left ranges of Min points
lengthsLeftMin = [left1,left3,left5,left7,left9];
%right ranges of Min points
lengthsRightMin = [right1,right3,right5,right7,right9];
%left ranges of Max points
lengthsLeftMax = [left2,left4,left6,left8];
%right ranges of Max points
lengthsRightMax = [right2,right4,right6,right8];

toReturn = zeros(9,2);
a = size(MinPoints);
% The loop goes over all suspect Min points and rules out those out of
% range
for i = 1:a
    for j = 1:5
        % if point is in range it's placed in proper location of output
        if   lengthsLeftMin(j) < MinPoints(i,1) && MinPoints(i,1) < lengthsRightMin(j);
            toReturn((2*j) -1, 1) = MinPoints(i,1);
            toReturn((2*j) -1, 2) = MinPoints(i,2);
        end
    end
end

a = size(MaxPoints);
% The loop goes over all suspect Max points and rules out those out of
% range
for i = 1:a
    for j = 1:4
         % if point is in range it's placed in proper location of output
        if   lengthsLeftMax(j) < MaxPoints(i,1) && MaxPoints(i,1) < lengthsRightMax(j);
            toReturn(2*j, 1) = MaxPoints(i,1);
            toReturn(2*j, 2) = MaxPoints(i,2);
        end
    end
end