function risePoint = getRise(Varray, dimensions)
% getRise
%
% Basic description: this method recieves an array containing the 
% histogram (number of pixels for every grey scale value) of the V value 
% of a BW image and the number of pixel in the image.
% it is excpected that the pixels representing the wave in the pendant 
% will be the darker pixels in the image.
% the method identifies and returns the optimal greyscale value seperating
% between the darker pixels (representing the wave)  and the brighter pixels
% (representing the pendant).

% Input: 
% Varray - the V histogram of a BW image
% dimensions - number of pixels in the original BW image
%
% Output: 
% risePoint - the optimal greyscale value seperating
% between the darker pixels (representing the wave)  and the brighter pixels
% (representing the pendant).
%
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses


% preanalaysis revealed that after cropping, a wave occupies 10 - 30 %
% of the whole image. startsum is the minimal number of pixels that
% is estimated the wave will ocupy of the image


%startsum is the minimal  number of pixels that is estimated that a wave will 
%occupy - 10%
startsum = (dimensions*10)/100;

%endsum is the maximal  number of pixels that is estimated that a wave will 
%occupy - 30%
endsum = (dimensions*30)/100;
% parameters initialized to 0 
startPoint = 0;
endpoint = 0;
counter = 0;
sum = 0;

% the objective of the two following loops is to find the 10% value and 30%
% value in the histogram this creating a rough range to locate risePoint.
%startPoint -  Computes left point of rough range.
for i = 1:256
    if sum > startsum
        startPoint = counter;
    break;
    end
    sum = sum + Varray(i);
    counter = counter + 1;
end

% endpoint -  Computes right point of rough range.
for i = startPoint:256
    if sum > endsum
        endpoint = counter;
        break;
    end
    sum = sum + Varray(i);
    counter = counter + 1;
end


% after narrowing the locations of the range where the rise may appear. the
% function fills holes:
% it locates within that range values with zero pixels and replaces the 
% Zero with the number of pixels that the value before recieved (extrapolation). This is
% done to prevent  "hole mistakes" in  the search for risePoint. 


% firstZero initialized to be endpoint in case no zero is found
firstZero = endpoint - 1;

% find the first zero in the range
for i = startPoint:endpoint
    if Varray(i) > 0
        firstZero = i;
        break;
    end;
end

% fill holes - finds any value that has zero pixels and replaces the 
% Zero with the preceding value.
VarrayNew = Varray;
for i = firstZero:endpoint
    if Varray(i) == 0;
        VarrayNew(i) = Varray(i - 1);
    end
end





% after the holes are filled, the function goes over every 20 values in the
% rough range (X1 - first 5, X2 - second 5, X3 - third five, X4 -fourth
% five)if the sum of X3 and the sum of X4 are more than twice the sum of X1
% we identify the point of rise to be approximatley in the beggining og X3.
% the progress of te 20 values window is a "moving window", namely the
% first window starts at value 1, the second at value 2, etc. 

% in case no rise will be found we attempt to continue by setting risePoint 
% to endPoint
rise = endpoint;

for i = startPoint:endpoint
    X1 = Varray(i) + Varray(i+1) + Varray(i+2) + Varray(i+3) + Varray(i+4);  
    %X2 = Varray(i+5) + Varray(i+6) + Varray(i+7) + Varray(i+8) + Varray(i+9); 
    X3 = Varray(i+10) + Varray(i+11) + Varray(i+12) + Varray(i+13) + Varray(i+14); 
    X4 = Varray(i+15) + Varray(i+16) + Varray(i+17) + Varray(i+18) + Varray(i+19); 
    if X1*2 < X3 && X1*2 < X4
        %lefttT = i;
        %rightT = i + 22;
        rise = i+10;
        break;
    end
end

% find point of rise
if Varray(rise) > Varray(rise-1)*2
    risePoint = rise - 1;
else risePoint = rise;
end
