function [ wave_img ] = GetWave( img )
%GETCIRCLES
% Basic description: This function takes an area containing a jewel
% and returns only the wave portion of the jewel, cropped and straightened.
% It it meant to be run after a detector located the jewel in an image.
%
% Input: 
% Image of a detected jewel cropped from a larger image.
%                   
% Output: 
% The wave portion of the jewel, cropped and straightened.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

img = SetSize(img);
[c r] = GetCircles(img);
angle = GetRotationAngle(c);
img = CropRotate(img, angle);
wave_img = CropWave(img);

end

