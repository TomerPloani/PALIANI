function [ rectangle ] = GetLargestRec( bbox )
%GetLargestRec
% Basic description: Returns the rectangle with the largest
% area from a set of given rectangles.
%
% Input: 
% Given set of rectangles.
%                   
% Output: 
% The largest rectangle in the set.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

s = size(bbox);
if (s==0)
    Disp('Failed to locate object.');
    return;
end

rows = s(1);
if (rows == 0)
    return;
end

max = 0;
max_index = 0;

for i=1:rows
    temp = bbox(i,3) * bbox(i,4);
    if (temp > max)
        max = temp;
        max_index = i;
    end
end

rectangle = bbox(max_index,:,:,:);

end

