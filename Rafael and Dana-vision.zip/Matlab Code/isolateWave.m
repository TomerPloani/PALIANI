function vectorWave = isolateWave(B)
% isolateWave
%
% Basic description: this method recieves a cell of Objects, each object
% representing the indexes of the exterior of an independant object. there
% is an assumption that the exteriot of the wave will be the largerst. the
% method returns the largest element in the cell which is the index
% representation of the exteriot of the wave.
% 
%
% Input: 
% B - cell of exterior of objects after basic preProcessing    
%                   
% Output: 
% vectorWave - vector of indexes of wave exterior
%
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses


% loop over all objects and return largest one
for k=1:numel(B)
  val(k)= numel(B{k});
end
out = B(val==max(val));

vectorWave = out{1,1};

end

