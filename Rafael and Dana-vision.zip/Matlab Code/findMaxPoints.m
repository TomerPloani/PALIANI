function [locsMax, pksMax, X, Y ] = findMaxPoints( arrayIndex )
% findMaxPoints
%
% Basic description: this method recieves an array representing a discrete
% function of the wave and returns all the Max points of the function.
% (There are suppose to be 4 Max points in the wave but because of
% preprocessing errors it may return a different number. this issue will be
% handled later in "checkExtremePoints")
%
% Input: 
% arrayIndex - an array representing a discrete fucnction of the wave.      
%                   
% Output: 
% locsMax - X values of detected Max points
% pksMax  - Y values of detected Max points
% X - x values of function for display in GUI
% Y - y values of function for display in GUI
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses


% x values of discrete function
X = arrayIndex(:,1);

% y values of discrete function
Y = arrayIndex(:,2);

%findpeaks - a matlab method returning max points of function
[pksMax,locsMax] = findpeaks(Y,X);





end

