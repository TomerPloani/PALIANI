function [locsMin, pksMin] = findMinPoints( arrayIndex )
% findMinPoints
%
% Basic description: this method recieves an array representing a descrete
% function of the wave and returns all the Min points of the function.
% (There are suppose to be 5 Min points in the wave but because of
% preprocessing errors it may return a different number. this issue will be
% handled later in "checkExtremePoints")
%
% Input: 
% arrayIndex - an array representing a discrete fucnction of the wave.      
%                   
% Output: 
% locsMax - X values of detected Min points
% pksMax  - Y values of detected Min points
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses

% x values of discrete function
X = arrayIndex(:,1);

% y values of discrete function
Y = arrayIndex(:,2);

% findpeaks - a matlab method returning max points of function
% by replacing Y with -Y, we switch between maximas and minimas of the
% function so when we use findpeaks, it return the minimas of the originall
% function instead of the maximas
[pksMin,locsMin] = findpeaks(-Y,X);

% the Y values of the function were turned positive in order to use
% "findpeaks" correctley. we now return the values to their original state.
pksMin = -pksMin;


end

