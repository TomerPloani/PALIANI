function [image,DBvector] = Comparison(Vector)
% Comparison
%
% Baic description: the function recieves a vector of Y values that
% represents the users pendant. It compares the recieved vector with all
% other vectors in database and returns the closest one.
%
% Input: 
% Vector - a vector of 9 values representing the users pendant.                    
%
% Output: 
% DBvector - most similar vector in database
% image - image corresponding to DBvector
%
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses


% creating database of pictures and corresponding vectors. the database
% consists of four different pendants a,b,c,d
aImage = imread('DB1.jpg');
aDB = [-5.049,9.1803,-1.5300,4.7432,-1.3770,10.0984,-3.2131,5.3552,-1.6831];
bImage = imread('DB2.jpg');
bDB = [-5.0217,5.0217,-1.5217,9.4348,-4.7174,9.7391,-3.0435,9.8913,-1.5217];
cImage = imread('DB3.jpg');
cDB = [-4.9677,9.7849,-4.9677,5.1183,-1.2043,8.7312,-2.8602,10.2366,-1.6559];
dImage = imread('DB4.jpg');
dDB = [-5.0217,8.9783,-5.1739,9.2826,-3.9565,9.8913,0.3043,10.1957,-1.5217];
eImage = imread('DB5.jpg');
eDB = [-3.8376,7.3909,-3.8376,5.9695,-1.2792,9.9492,-5.1168,4.9746,-3.1269];
fImage = imread('DB6.jpg');
fDB = [-5.0149,4.5970, -1.3930,4.5970,-1.2537,9.7512,-3.0647,5.4328,-1.5323];
gImage = imread('DB7.jpg');
gDB = [-2.6337,8.3168,-3.6040,6.3762,-3.8812,9.9802,-1.8020,8.7327,-1.8020];

% compute distance between input vector and each of the vectors in database
% for that we use the L2 norm distance (squared).
aVal = sum((aDB - Vector).^2);
bVal = sum((bDB - Vector).^2);
cVal = sum((cDB - Vector).^2);
dVal = sum((dDB - Vector).^2);
eVal = sum((eDB - Vector).^2);
fVal = sum((fDB - Vector).^2);
gVal = sum((gDB - Vector).^2);

% find which distance is smallest to identify most similar vector
minArr = [aVal,bVal,cVal,dVal,eVal,fVal,gVal];
Min = min(minArr);

% Find image and DB vector corresponfing to smallest distance
if (aVal == Min)
    image = aImage;
    DBvector = aDB;
end

if (bVal == Min)
    image = bImage;
    DBvector = bDB;
end

if (cVal == Min)
    image = cImage;
    DBvector = cDB;
end

if (dVal == Min)
    image = dImage;
    DBvector = dDB;
end

if (eVal == Min)
    image = eImage;
    DBvector = eDB;
end

if (fVal == Min)
    image = fImage;
    DBvector = fDB;
end

if (gVal == Min)
    image = gImage;
    DBvector = gDB;
end