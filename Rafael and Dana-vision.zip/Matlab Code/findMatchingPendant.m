function [Vector,DBimage,DBvector,BW,middleLine,X,Y,XforPlot,YforPlot] = findMatchingPendant(I)
% findMatchingPendant
%
% Basic description: this method recieves a cropped image of the wave
% within the pendant. Its purpose is to find and return the wave that is
% the most fitting match from the database. 
%
% Input: 
% I -  a cropped image of the original user image. The image is cropped so 
% that only the wave and part of the pendant (rectangular disk) will appear.
%                   
% Output: 
% Vector - a vector representation of I (vector of zise 9 representing the
% relative heights of extre points of wave).
% DBimage- image of best matching pendant from database
% DBvector- vector representation of DBimage
% BW- an image of the input after isolating wave from pendant (for
% demonstration purposes in GUI)
% middleLine-  an image of the function representing the wave (for
% demonstration purposes in GUI)
% x,y,xforPlot,yforPlot- parameters for plotting extreme points (for
% demonstration purposes in GUI)


% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses

% Preprocess cropped image to get a black/white image of the exterior of
% the wave without any noises
[processedImage,firstX,lastX,BW] = preProcess(I);

% turn the wave into a discrete function representing the middle
% line of the wave
[arrayIndex,middleLine] = turnToFunction(processedImage,firstX,lastX);

% normalize the function so that the X axis of the function will be the X
% axis of the wave itself
arrayIndexN = normalizeArray(arrayIndex);

% find the Max extreme points of the function
[locsMax, pksMax,X,Y] = findMaxPoints(arrayIndexN);

% find the Min extreme points of the function
[locsMin, pksMin ] = findMinPoints(arrayIndexN);

% Compute length of X axis 
Xlength = lastX - firstX + 1;

% combine X and Y values of Max points
fullMax = [locsMax,pksMax];

% combine X and Y values of Min points
fullMin = [locsMin,pksMin];

% checks wether all exreme points are in expeced location based on preknown
% fetures of the pendant
fullEPVector = checkExtremePoints(fullMin,fullMax,Xlength);

% parameters for demonstration in GUI
XforPlot = fullEPVector(:,1);
YforPlot = fullEPVector(:,2);

% check if there are any zeros in fullEPVector, if there are return "make
% another picture"
n = nnz(fullEPVector);
if (n ~= 18)
    error('take another picture');
end


% assign numeric values to the wave for future comparison with other waves
% in the database
Vector = assignNumericVals(fullEPVector,Xlength);

% get best-matching image from database
[DBimage,DBvector] = Comparison(Vector);