function [processedImage,firstX,lastX] = createProcessedImage(I,Wave)
% createProcessedImage
%
% Basic description: this method recieves the (x,y) indexes of the wave 
% exterior and outputs an image where the wave exterior is white and
% the background is black.
%
% Input: 
% I - originall rgb image of pendant after homography used only for dimensions   
% Wave - array of (x,y) indexes of the exterior of the wave
%
% Output: 
% processedImage - binary image of the exterior of the wave without any
% noises
% firstX - begining of wave
% lastX - end of wave
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses


% get dimensions of originall image
[m,n,~] = size(I);
[index,~] = size(Wave);

% create a black image of a size identicle to originall image
processedImage = zeros(m,n);

% loop over array of wave indexes and plot them in white upon the black
% image creating a black/white image of wave exterior
for i= 1:index
    a = Wave(i,1);
    b = Wave(i,2);
    processedImage(a,b) = 255;
end

% find begining X index of wave
firstX = min(Wave(:,2));

% find ending X index of wave
lastX = max(Wave(:,2));


end

