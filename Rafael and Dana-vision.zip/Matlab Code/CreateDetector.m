function [ detector ] = CreateDetector( xml_path )
%CreateDetector
%
% Input: 
% A path (string) of an xml file to be used in a cascade object detector.
%                   
% Output: 
% A cascade object detector created from the given xml file.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

detector = vision.CascadeObjectDetector(xml_path);

end

