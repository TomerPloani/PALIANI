function [ f_centers, f_radii ] = FilterCircles( img, centers, radii)
%FilterCircles
% Basic description: This function receives a set of circles, and
% filters out irrelevant circles. 
% The function will return the two closest-matching circles which are
% roughly on opposing sides of the image.
%
% Input: 
% Image, centers of circles, radii of circles.
%                   
% Output: 
% Two best matching circles according to specifications.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

radii_size = size(radii);
num_of_circles = radii_size(1);
if (num_of_circles < 2)
    error('There are less than 2 circles in input. Try increasing the circle detection sensitivity.');
    return;
end

Sides = 0.25;
CenterStripe = 0.3;

imgSize = size(img);
imgWidth = imgSize(2);
imgHeight = imgSize(1);

index = 1;

%Filter circles from predermined areas.
for (i = 1:size(centers))
    if ((centers(i,1) < imgWidth * Sides) ...
            || (centers(i,1) > imgWidth * (1-Sides)))
        if ((centers(i,2) > imgHeight * CenterStripe) ...
                && (centers(i,2) < imgHeight * (1-CenterStripe)))
            
            %viscircles([centers(i,1) centers(i,2)],radii(i), 'EdgeColor','r');
            
            centers_filtered(index, 1) = centers(i, 1);
            centers_filtered(index, 2) = centers(i, 2);
            radii_filtered(index,1) = radii(i);
            index = index + 1;
        end
    end
end

radii_filtered_size = size(radii_filtered);
num_of_filtered_circles = radii_filtered_size(1);

if (num_of_filtered_circles < 2)
    error('Not enough circles in designated areas. Try increasing the circle detection sensitivity.');
    return;
end

%Choose closely matching radii
min_diff = realmax;
index_1 = 0;
index_2 = 0;

for (i=1:size(radii_filtered))
    for (j=1:size(radii_filtered))
        if (i ~= j)
            temp_diff = abs(radii_filtered(i) - radii_filtered(j));
            if (temp_diff < min_diff)
                min_diff = temp_diff;
                index_1 = i;
                index_2 = j;
            end
        end
    end
end

f_centers(1,:) = centers_filtered(index_1,:);
f_centers(2,:) = centers_filtered(index_2,:);
f_radii(1,1) = radii_filtered(index_1);
f_radii(2,1) = radii_filtered(index_2);

            
            

end

