function [ img ] = CropRotate( img, angle )
%CropRotate
% Basic description: This function will rotate an image in the
% given angle, and crop areas in which new pixels were introduced.
%
% Input: 
% Image to be treated.
%                   
% Output: 
% The given image, rotated and cropped according to given angle.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

img = imrotate(img, angle, 'bilinear');
s = size(img);
crop_y = int16(s(2)*sin(degtorad(angle)));
crop_x = int16(s(1)*sin(degtorad(angle)));
width = s(2) - crop_x;
height = s(1) - crop_y;
x = 1 + crop_x;
y = 1 + crop_y;
img = imcrop(img, [x, y, width - x, height - y]); 

end

