function [ wave_img ] = CropWave( img)
%CropWave
% Basic description: This function crops an image based on pre-defined
% characteristics of a jewel, supposedly contained within the image.
% It returns a cropped area containing only the wave portion of a jewel.
% This function is meant to be called after CropRotate.
%
% Input: 
% A straightened, cropped image of a jewel.
%                   
% Output: 
% A cropped image containing only the wave portion of the jewel.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

[centers, radii] = GetCircles(img);

wave_center_x = abs(centers(1,1) - centers(2,1)) / 2 + min(centers(:,1));
wave_center_y = abs(centers(1,2) - centers(2,2)) / 2 + min(centers(:,2));

r = 0.5*radii(1) + 0.5*radii(2);

%upper left
x = int16(wave_center_x - 8*r);
y = int16(wave_center_y - 4.5*r);
width = int16(16*r);
height = int16(9*r);

rectangle = [x, y, width, height];

wave_img = imcrop(img, rectangle);

end

