function [arrayIndex,I2] = turnToFunction(I,firstX,lastX)
% turnToFunction
% 
%
% Basic description: this method recieves a black/white image of the
% exterior of the wave and returns a discrete function in the form of a 
% vector that represent the middle line of the wave. The method also plots
% the funciton.

% Input: 
% I - a black/white image of the exterior of the wave
% firstX - X index of begining of wave
% lastX  - X index of ending of wave

% Output: 
% arrayIndex - a 2-dimensional array representing the (x,y) values of the
% function computed.
% I2 - an image representing the function (function in white BG in black)
% this is done for demonstration in GUI.
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses



% create a black image upon which the function will be plotted in white
[m,n,~] = size(I);
I2 =zeros(m,n);

% Compute the length of the X - axis of the function
Xlength = lastX - firstX + 1;

% initialize the vector representing the function to zero
arrayIndex = zeros(Xlength,2);

% loop over the exterior of the wave to compute the function. 
% for each X value,the Y value will be the average of the Y value
% of the upper point of the wave and of the lower point of the wave.
for i = firstX:lastX
    temporary = I(:,i);
    if (any(temporary) == 1)
        % a: find the Y value of upper point of wave
        a = find(temporary>0,1);
        % b: find the Y value of lower point of wave
        b = find(temporary>0,1,'last');
        % plot in Image
        I2(ceil((a+b)/2), i) = 255;
        % set X value of each point in the vector representing the function
        arrayIndex(i - firstX + 1,1) = i - firstX + 1;
        % set Y value of each point in the vector representing the function
        arrayIndex(i - firstX + 1,2) = ceil((a+b)/2);
    else
        continue
    end
end


end

