function arrayIndexNormal = normalizeArray(arrayIndex)
% normalizeArray
%
% Basic description: this method recieves the mathematical function of
% the wave. The recieved function relates to the first line in the matrix
% of the image as the X axis. There is an assumption the the first and
% last points of the wave form the X axis of the wave. the method "normalizes" the 
% functions values to relate to that line to be the X axis.
%
% Input: 
% arrayIndex - the function representing the wave unnormalized       
%                   
% Output: 
% normalizeArray - the function representing the wave normalized
%
% Rafael Ben-Ari, Dana Levin, 2016
% Application In Computer Vision Workshop, Prof. Yael Moses


% Yzero finds the height of the first value in the function. the height of
% the first value will turn into the X-axis of the new function.
Yzero = arrayIndex(1,2);


arrayIndexNormal = arrayIndex;

%subtract Yzero from all heights of the function to get the new normalized
%heights in relation to the new X axis.
arrayIndexNormal(:,2) = arrayIndexNormal(:,2) - Yzero;

arrayIndexNormal(:,2) = -arrayIndexNormal(:,2);

end
