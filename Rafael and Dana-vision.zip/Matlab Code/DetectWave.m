function [ wave_img ] = DetectWave( img, path )
%DetectWave
% Basic description: This is a high-level function created to
% easily extract the wave portion of a jewel out of an image
% containing the jewel somewhere. The function will use a 
% cascade object detector based on the given path to an XML file.
%
% Input: 
% Image containing a jewel, path to XML file for creation of
% a cascade object detector.
%                   
% Output: 
% The wave portion of the jewel, cropped and straightened.
%
% Rafael Ben-Ari, Dana Levin, 2017
% Application In Computer Vision Workshop, Prof. Yael Moses

d = CreateDetector(path);
jewel_img = imcrop(img, Detect(d, img));
wave_img = GetWave(jewel_img);

end

